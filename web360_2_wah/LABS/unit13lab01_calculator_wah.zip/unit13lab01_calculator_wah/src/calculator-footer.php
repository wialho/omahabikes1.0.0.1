<footer>
  <p><em>Copyright &copy; 2017 Insight Inc.</em></p>
</footer>